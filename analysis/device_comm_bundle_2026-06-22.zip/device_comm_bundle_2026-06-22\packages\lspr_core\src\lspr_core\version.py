from __future__ import annotations

APP_NAME = "LSPR Core"
APP_VERSION = "0.1.0"
__version__ = APP_VERSION


def version_string() -> str:
    return f"{APP_NAME} {APP_VERSION}"
