"""Spectrometer backends."""
