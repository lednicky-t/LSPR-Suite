"""PyQt GUI."""
